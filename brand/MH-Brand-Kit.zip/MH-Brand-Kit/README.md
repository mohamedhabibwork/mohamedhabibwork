# MH Brand Kit · Mohamed Habib, Tech Lead

Everything is vector where it can be (text outlined; no fonts needed to open logos).

| Folder | Contents |
|---|---|
| `01-illustrator/` | **MH-Brand-Kit.ai** (27 artboards: 11 logo versions + 16 social formats), MH-Logo.ai, MH-Social-Kit.ai, and matching PDFs. Open in Adobe Illustrator: each artboard is editable vector. |
| `02-logos/` | Every logo version as SVG, PDF, EPS and PNG (480–2400px): horizontal & stacked lockups (dark/light), mark (lime/black/white), app icons. |
| `03-social/` | LinkedIn, X, Facebook, YouTube covers; GitHub & Open Graph previews; Instagram post & story; profile pictures; video-call background; title slide; email signature; business card. SVG, PNG (exact platform sizes), PDF. |
| `04-app-icons/` | Favicons (.ico/.svg), Apple touch icon, PWA any + maskable, Android adaptive layers, Windows tile, Safari pinned tab, App Store 1024, `site.webmanifest`, `browserconfig.xml`, `head-snippet.html`. |
| `05-ui-icons/` | 68 interface icons, 24px stroke SVG (ink #8a8f7f). |
| `06-fonts/` | Barlow, Poppins, Readex Pro (Arabic), JetBrains Mono: TTF (desktop/Illustrator) + WOFF2 (web). SIL Open Font License. |
| `07-images/` | Profile portrait, project covers, CV template thumbnails. |
| `08-design-tokens/` | `tokens.json` (colours, type, spacing, radius, shadows; dark + light) and `brand-guide.md`. |

## Colours
| | Hex | RGB | Use |
|---|---|---|---|
| Lime | #C2F852 | 194 248 82 | The mark, primary actions. Never as text on white. |
| Carbon | #0B0D0A | 11 13 10 | Backgrounds, the mark on light grounds |
| Bone | #FAFAF7 | 250 250 247 | Light backgrounds |
| Olive | #3D5806 | 61 88 6 | Lime-family text on light |

Lime is an RGB colour; for print, match against a Pantone swatch (≈ 375 C / 2297 C) rather than trusting a CMYK conversion.

## Rules
- Clear space: the height of the H's crossbar on every side. Minimum: mark 16px tall, lockup 120px wide.
- Lime mark on dark grounds; carbon mark on light. Don't recolour, stretch, outline or add effects.
- Install the fonts from `06-fonts/` before editing type in Illustrator (logo text is already outlined).
